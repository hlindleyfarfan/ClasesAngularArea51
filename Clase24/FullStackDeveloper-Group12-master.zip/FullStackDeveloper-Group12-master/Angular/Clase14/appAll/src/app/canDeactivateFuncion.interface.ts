export interface canDeactivateFuncion {
  canDeactivateData: () => boolean
}
