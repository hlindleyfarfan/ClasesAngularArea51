export const environment = {
  production: true,
  rutaApiRest: "http://clase.tibajodemanda.com"
};
