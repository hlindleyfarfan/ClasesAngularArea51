import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edicion-usuario',
  templateUrl: './edicion-usuario.component.html',
  styleUrls: ['./edicion-usuario.component.css']
})
export class EdicionUsuarioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
