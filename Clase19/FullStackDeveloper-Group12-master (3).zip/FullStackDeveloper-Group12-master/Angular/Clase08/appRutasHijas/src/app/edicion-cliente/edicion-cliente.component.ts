import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edicion-cliente',
  templateUrl: './edicion-cliente.component.html',
  styleUrls: ['./edicion-cliente.component.css']
})
export class EdicionClienteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
