import { UploadDirective } from './upload.directive';

describe('UploadDirective', () => {
  it('should create an instance', () => {
    const directive = new UploadDirective();
    expect(directive).toBeTruthy();
  });
});
