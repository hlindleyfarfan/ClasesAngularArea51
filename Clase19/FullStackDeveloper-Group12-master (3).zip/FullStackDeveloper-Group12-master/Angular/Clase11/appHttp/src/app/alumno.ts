export interface Alumno {
  _id?: string
  nombre?: string
  apellido?: string
}
