export interface ICurso {
  nombre: string
  cantidad: number
  estado?: boolean
}
