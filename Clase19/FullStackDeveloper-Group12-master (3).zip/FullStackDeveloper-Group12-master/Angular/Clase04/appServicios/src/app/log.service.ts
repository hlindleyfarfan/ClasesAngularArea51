export class LogService {
  escribir(texto: string) {
    console.log("INFO:", texto)
  }
}
