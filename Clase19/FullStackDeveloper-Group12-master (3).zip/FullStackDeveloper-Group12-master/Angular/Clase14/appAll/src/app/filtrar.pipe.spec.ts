import { FiltrarPipe } from './filtrar.pipe';

describe('FiltrarPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltrarPipe();
    expect(pipe).toBeTruthy();
  });
});
