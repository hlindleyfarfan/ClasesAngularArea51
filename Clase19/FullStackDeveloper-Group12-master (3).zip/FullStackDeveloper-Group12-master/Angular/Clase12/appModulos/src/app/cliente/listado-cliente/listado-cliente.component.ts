import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listado-cliente',
  templateUrl: './listado-cliente.component.html',
  styleUrls: ['./listado-cliente.component.css']
})
export class ListadoClienteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
