import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listado-transportista',
  templateUrl: './listado-transportista.component.html',
  styleUrls: ['./listado-transportista.component.css']
})
export class ListadoTransportistaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
